import os
import sys
import math
import numpy as np
import cv2 as cv
from PIL import Image
#import piexif
import time

import inclusion
import utils
import model as modellib
import visualize2
import show
import show2
from tkinter.filedialog import *
from tkinter import *
import datetime


#Paramêtres
sho=1 #affichage dtection
clean=1 #netoyage image

# Root directory of the project
ROOT_DIR = os.getcwd()

# Directory to save logs and trained model
MODEL_DIR = os.path.join(ROOT_DIR, "logs")

# Local path to trained weights file
COCO_MODEL_PATH = os.path.join(ROOT_DIR, "mask_rcnn_inclusion.h5")
# Directory of images to run detection on
fenetre = Tk()
filepath = askopenfilename(title="Ouvrir la premiere image de la serie")
fenetre.destroy()
    
IMAGE_DIR=os.path.dirname(filepath)

config = inclusion.BalloonConfig()
class InferenceConfig(config.__class__):
    # Run detection on one image at a time
    GPU_COUNT = 1
    IMAGES_PER_GPU = 1
    DETECTION_MIN_CONFIDENCE = 0.9
    RPN_NMS_THRESHOLD = 0.7

config = InferenceConfig()
config.display()
# Create model object in inference mode.
model = modellib.MaskRCNN(mode="inference", model_dir=MODEL_DIR, config=config)

# Load weights trained on MS-COCO
model.load_weights(COCO_MODEL_PATH, by_name=True)

# COCO Class names
# Index of the class in the list is its ID. For example, to get ID of
# the teddy bear class, use: class_names.index('teddy bear')
class_names = ['BG', 'rayure', 'sal', 'a','c','d','ni']

# Load a random image from the images folder
noms = os.listdir(IMAGE_DIR)


#suppression des fichiers non image
noms= [nom for nom in noms if nom[-4:] == ".tif" or nom[-4:] == ".Tif" or nom[-4:] == ".bmp" or nom[-4:] == ".jpg"]
nb_image=len(noms)


path=os.path.join(IMAGE_DIR,'IA')
try:
    os.mkdir(path)
except OSError:
    pass
path2=os.path.join(IMAGE_DIR,'Clean')
try:
    os.mkdir(path2)
except OSError:
    pass
t0=time.time()
i=0
l=len(noms)
for nom in noms:
    i=i+1
    t=time.time()
    nfc = os.path.join(IMAGE_DIR, nom)
    image=cv.imread(nfc)
    #exif_dict = piexif.load(nfc)
    print(nom)

    #recuperation pâramêtre olympus
    
    fd = open(nfc, 'rb')
    d= fd.read()
    xmp_start = re.search(b'analySIS',d)
    xmp_end = re.search(b'Solutions',d)
    xmp_str = d[:xmp_end.span()[0]+11]
    xmp_str2 = d[xmp_start.span()[0]-16:]
    fd.close()
    t1=time.time()
    # Run detection
    results = model.detect([image], verbose=0)
    # Save results
    r = results[0]
    t2=time.time()

    if sho+clean!=0:
        if sho==1:
            img=show.show(image,r['rois'],r['masks'], r['class_ids'],class_names,r['scores'],sho,clean)

            nom_ia=nom[:-4]+".jpg"
            img.save(os.path.join(path,nom_ia))

            del image
            del img

            image=cv.imread(nfc)

        if clean==1:
            img2=show2.show(image,r['rois'],r['masks'], r['class_ids'],class_names,r['scores'],sho,clean)

            img2.save(os.path.join(path2,nom))

            fd = open(os.path.join(path2,nom), 'rb')
            d= fd.read()
            fd.close()
            d=xmp_str+d[140:]+xmp_str2
            fd = open(os.path.join(path2,nom), 'w+b')
            fd.write(d)
            fd.close()

            del image

    t3=time.time()
    T1=t1-t
    T2=t2-t1
    T3=t3-t2
    T=t3-t
    print('Temps ouverture: %.2f s Temps IA %.2f s Temps ecriture %.2f s'%(T1,T2,T3))
    print('Temps total: %.2f s'%T)
    print('Temps estimé restant : %s'%str(datetime.timedelta(seconds=round((t3-t0)/i*(l-i)))))
