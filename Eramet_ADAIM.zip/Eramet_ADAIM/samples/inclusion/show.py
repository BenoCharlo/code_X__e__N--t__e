import numpy as np
import os
import random
import math
from PIL import Image, ImageFont,ImageDraw,ImageEnhance

import utils

#affichage des resultats IA

def show(imag,boxes, masks, class_ids,class_names,scores,show,clean):
# Number of instances
    N=np.size(class_ids)
    if  N>0:
        alpha=0.4
        h,w,c=imag.shape
        #####        
        for i in range(N):  #Prioritasiation des éléments important + coloration des mask
            class_id = class_ids[i]
            mask = masks[:, :, i]
            
            if show==1:
                #Creation mask coloré
                if class_id==1:
                    color=[1,0,0]
                if class_id==2:
                    color=[1,0.41,0]
                if class_id==3:
                    color=[1,0.76,0.3]
                if class_id==4:
                    color=[0,1,0]
                if class_id==5:
                    color=[0,1,0]
                if class_id==6:
                    color=[0,0,1]
                I=np.mean(imag)
                for c in range(3):
                    
                    imag[:, :, c] = np.where(mask == 1,imag[:, :, c] *(1 - alpha) + alpha * color[c] * 255,imag[:, :, c])
        
            im=Image.fromarray(imag)
            draw=ImageDraw.Draw(im)

            for i in range(N):
                class_id = class_ids[i]

                 #affichage label
                y1, x1, y2, x2 = boxes[i]
                score = scores[i] if scores is not None else None
                label = class_names[class_id]
                x = random.randint(x1, (x1 + x2) // 2)
                caption = "{} {:.3f}".format(label, score) if score else label
                draw.text((x1, y1 + 8),caption,font=ImageFont.truetype('arial.ttf',14),fill='red')

    else:
        im=Image.fromarray(imag)
    return im
