import os
    

def getListOfFiles(dirName,dirName1):
    # create a list of file and sub directories 
    # names in the given directory 
    listOfFile = os.listdir(dirName)
    allFiles = list()
    # Iterate over all the entries
    for entry in listOfFile:
        # Create full path
        fullPath = os.path.join(dirName, entry)
        # If entry is a directory then get the list of files in this directory 
        if os.path.isdir(fullPath):
            allFiles = allFiles +getListOfFiles(fullPath,dirName1)
        else:
            allFiles.append(fullPath.replace(dirName1,""))       
    return allFiles

def createFolder(dirName1,dirName2):
    # create a list of file and sub directories 
    # names in the given directory 
    listOfFile1 = os.listdir(dirName1)
    # Iterate over all the entries
    for entry in listOfFile1:
        # Create full path
        fullPath1 = os.path.join(dirName1, entry)
        # If entry is a directory then get the list of files in this directory 
        if os.path.isdir(fullPath1):
            path=os.path.join(dirName2,entry)         
            try:
                os.mkdir(path)
            except OSError:
                pass
            fullPath2 = os.path.join(dirName2, entry)
            createFolder(fullPath1,fullPath2)



if __name__ == '__main__':
    dirName1 = 'D:\essai'
    dirName2 = 'D:\essai-bis'

    listOfFiles1 = getListOfFiles(dirName1,dirName1)
    listOfFiles2=getListOfFiles(dirName2,dirName2)
    print('diff')
    file_diff = sorted(list(set(listOfFiles1) - set(listOfFiles2)))
    print(len(file_diff))
    createFolder(dirName1,dirName2)
    
    
    
        


    
    
    
