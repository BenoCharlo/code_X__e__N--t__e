import cv2
import numpy
import show




def main():
    #Paramêtres
    show=1 #affichage dtection
    clean=0 #netoyage image

    class InferenceConfig(config.__class__):
        # Run detection on one image at a time
        GPU_COUNT = 1
        IMAGES_PER_GPU = 1
    # Create model object in inference mode.
    model = modellib.MaskRCNN(mode="inference", model_dir=MODEL_DIR, config=config)

    # Load weights trained on MS-COCO
    model.load_weights(COCO_MODEL_PATH, by_name=True)

    # COCO Class names
    # Index of the class in the list is its ID. For example, to get ID of
    # the teddy bear class, use: class_names.index('teddy bear')
    class_names = ['BG', 'rayure', 'sal', 'a','c','d','ni']


    cam = cv2.VideoCapture(0)
    while True:
        ret_val, img = cam.read()
        if mirror: 
            img = cv2.flip(img, 1)
        results=model.detect([img])
        r = results[0]
        imgC,imgS=show.show(image,r['rois'],r['masks'], r['class_ids'],class_names,r['scores'],show,clean)
        if show==1:
            im=np.concatenate((img,imgS),axis=1)
        else:
            im=np.concatenate((img,imgC),axis=1)
        cv2.imshow('my webcam +IA', im)
        
        if cv2.waitKey(1) == 27: 
            break  # esc to quit
    cv2.destroyAllWindows()



if __name__ == '__main__':
    main()
