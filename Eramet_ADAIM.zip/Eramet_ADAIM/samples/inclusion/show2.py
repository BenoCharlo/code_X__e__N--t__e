import numpy as np
import os
import random
from PIL import Image, ImageFont,ImageDraw,ImageEnhance

import utils


#supression des defeauts

def show(imag,boxes, masks, class_ids,class_names,scores,show,clean):
# Number of instances
    N=np.size(class_ids)
    if  N>0:
        alpha=0.8
        h,w,c=imag.shape
        if clean==1:
            img=imag
        #####

        #Recherche inclusions
        mask_T1=[masks[:,:,i] for i in range(N) if class_ids[i]>2]
        mask_T=np.sum(mask_T1,axis=0)
        if np.size(mask_T)==1:
            mask_T=np.zeros((h,w))
            
        

        mask1=[masks[:,:,i] for i in range(N) if class_ids[i]<3]
        mask=np.sum(mask1,axis=0)
        if np.size(mask)==1:
            mask=np.zeros((h,w))

        mask=np.where(mask_T>0,0,mask)

        #supression saleté
        for c in range(3):
                Im=np.mean(img[:, :, c])
                img[:, :, c] = np.where(mask>0 ,Im,img[:, :, c])

        img=Image.fromarray(img) 
    else:
        img=Image.fromarray(imag)

    return img
