import os
from tkinter import *


if __name__ == '__main__':

    #Fichier paramêtres
    x =  sys.argv[1]+'.txt'
    with open(x, "r") as fichier:
    	 contenu = fichier.readlines()
    	 
    	 adresse=os.path.normpath(contenu[19].strip())
    #Lecture des nuances
    with open('nuances.txt', "r") as fichier:
        contenu = fichier.readlines()

    #exectution une fois le choix fait
    def fetch():
        nuance=list.get(ACTIVE).strip()
        root.destroy()
        link=os.path.join(adresse,nuance)
        cmd='py inclusion.py train --dataset='+link+' --weights=coco'
        print(cmd)
        #exectution apprentissage
        os.system(cmd)
        link2=os.path.join(os.getcwd(),'database')
        #deplacement vers le bon répertoire + changement de nom corespondant nuance
        os.rename('mask_rcnn_inclusion.h5',nuance+'.h5')
        os.system('move '+nuance+'.h5 '+link2)
        os.system("shutdown /s /t 1")
        
        
    #creation affichage
    root = Tk()
    list = Listbox(root)
    list.pack(side=TOP)
    Button(root, text='ok', command=fetch).pack()
    for index in range(0,len(contenu)):
        list.insert(index, contenu[index])
    root.mainloop()
