import numpy as np
import cv2 as cv
from scipy import ndimage

def canny_transform(image, binarize=True, minVal=100,maxVal=120):
    
    image_gray = cv.cvtColor(image,cv.COLOR_RGB2GRAY)
    edges = cv.Canny(image_gray, minVal, maxVal)
    if binarize:
        edges[edges>1]=1

    return edges

def tensorize(array,shape):

    arr = np.array([array]*shape)
    return arr.transpose()
    
def compute_recovery_rate(masks1, masks2):
    '''Computes IoU overlaps between two sets of masks.
    masks1, masks2: [Height, Width, instances]
    '''
    # flatten masks
    masks1 = np.reshape(masks1 > .5, (-1, masks1.shape[-1])).astype(np.float32)
    masks2 = np.reshape(masks2 > .5, (-1, masks2.shape[-1])).astype(np.float32)
    area1 = np.sum(masks1, axis=0)
    area2 = np.sum(masks2, axis=0)

    # intersections and union
    intersections = np.dot(masks1.T, masks2)
    union = area1[:, None] #+ area2[None, :] - intersections
    overlaps = intersections / union

    return overlaps

def fill_edges(edges):
    for i in range(edges.shape[0]):
        gate = False
        for j in range(edges.shape[0]):
            if gate:
                if edges[i,j] == 0:
                    edges[i,j] = 1
                else:
                    gate=False
            else:
                if edges[i,j] > 0:
                    gate=True
    
    return edges

def eval_segmentation(masks1, masks2, multiply=True):
    
    ious = compute_recovery_rate(masks1, masks2)    
    values = []   
    for iou in ious:
        if multiply:
            values.append(iou[0]*100)
        else:
            values.append(iou[0])
    return values

def gaussian_filter_on_mask(gt_mask):
    
    mask_contour = []
    
    for i in range(gt_mask.shape[2]):
        im = np.array(gt_mask[:,:,i], dtype=float)
        
        lowpass = ndimage.gaussian_filter(im, 3)
        gauss_highpass = im - lowpass
        mask_contour.append(gauss_highpass)
        
    return np.array(mask_contour).transpose()

def Laplacian_Gaussian_effect_on_mask(gt_mask, gaussian=False, filter_size=7):

    if gaussian:
        gt_blur = cv.GaussianBlur(gt_mask, (filter_size,filter_size),2)
    else:
        gt_blur = cv.GaussianBlur(gt_mask, (filter_size,filter_size),2)
        gt_blur = cv.Laplacian(gt_blur, cv.CV_64F)

    return gt_blur

def plot(data, title):
    plot.i += 1
    plt.subplot(2,2,plot.i)
    plt.imshow(data)
    plt.gray()
    plt.title(title)
plot.i = 0

def eval_classif(tbg, score_threshold, recovery_threshold):

    tbg_s = tbg[tbg.Score_pred>score_threshold]
    nb_elements = tbg_s.shape[0]/tbg.shape[0] * 100
    print('Seuil: ', score_threshold, "Pourcentage d'objets trouvés: ", np.round(nb_elements,3), '%')
    
    var_recov = 'Recovery_rate_'+str(recovery_threshold)
    tbg_r = tbg_s[tbg_s[var_recov]==1]
    nb_elements_rec = tbg_r.shape[0]/tbg_s.shape[0] * 100

    print('Taux de recouvrement considéré: ', recovery_threshold, \
          "Pourcentage d'objets trouvés: ", round(nb_elements_rec,3), '%')
    
    tbc = list((tbg_r['Class_gt'] == tbg_r['Obj_pred']*1) & (tbg_r['Proximity'] == 1)*1)
    precision = sum(tbc)/len(tbc)*100
    
    return np.round(precision,3)
