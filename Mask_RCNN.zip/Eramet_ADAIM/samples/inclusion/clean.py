import numpy as np
import os
from PIL import Image, ImageFont,ImageDraw,ImageEhance

import utils

def clean(image, masks, class_ids):
    """
    boxes: [num_instance, (y1, x1, y2, x2, class_id)] in image coordinates.
    masks: [height, width, num_instances]
    class_ids: [num_instances]
    class_names: list of class names of the dataset
    scores: (optional) confidence scores for each box
    figsize: (optional) the size of the image.
    """
    # Number of instances
    N=np.size( class_ids)
    if  N>0:

        
        h,w,c=image.shape
        mask_T=np.zeros([h,w])

        for i in range(N): #Prioritasiation des éléments important

            class_id = class_ids[i]
            if class_id>2: #Attention 1 pour TI pour inclusion à modifier
                mask = masks[:, :, i]
                mask_T = np.where(mask == 1,1,mask_T)
                
        for i in range(N):  #supression des éléments indissérable sur l'image
            

            class_id = class_ids[i]
            if class_id<3: #Attention 1 pour TI pour inclusion à modifier
            

            # Mask
                mask = masks[:, :, i]
                Im=np.mean(image)
                for c in range(3):
                    image[:, :, c] = np.where(mask-mask_T == 1,Im,image[:, :, c])

    else:
        im=image
    return im

def show(image,boxes, masks, class_ids,class_names,scores=None):
# Number of instances
    N=np.size(class_ids)
    if  N>0:

        
        h,w,c=image.shape
        mask_T=np.zeros([h,w])

                
        for i in range(N):  #supression des éléments indissérable sur l'image
            

            class_id = class_ids[i]
            if class_id==1:
                f='red'
                color=[1,0,0]
            else if class_id==2:
                f='orange'
                color=[1,0.41,0]
            else if class_id==3:
                f='yellow'
                color=[1,0.76,0.3]
            else if class_id==4:
                f='bleu'
                color=[0,1,0]
            else if class_id==5:
                f='blue'
                color=[0,1,0]
            else if class_id==5:
                f='green'
                color=[0,0,1]
            
            # Mask
            mask = masks[:, :, i]
            im=apply_mask(image, mask, color)
            y1, x1, y2, x2 = boxes[i]
            score = scores[i] if scores is not None else None
            label = class_names[class_id]
            x = random.randint(x1, (x1 + x2) // 2)
            caption = "{} {:.3f}".format(label, score) if score else label
            draw=ImageDraw.Draw(im)
            draw.text((x1, y1 + 8),caption,font=ImageFont.truetype('arail.ttf',14))
            draw.rectangle(((x1,y1),x2,y2)),fill=f[class_ids])

    else:
        im=image

def apply_mask(image, mask, color, alpha=0.5):
    """Apply the given mask to the image.
    """
    for c in range(3):
        image[:, :, c] = np.where(mask == 1,
                                  image[:, :, c] *
                                  (1 - alpha) + alpha * color[c] * 255,
                                  image[:, :, c])
    return image
