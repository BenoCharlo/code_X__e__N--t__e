import os
import sys
import math
import numpy as np
import cv2 as cv
from PIL import Image
#import piexif
import time

import inclusion
import utils
import model as modellib
import visualize2
import show
import show2
from tkinter.filedialog import *
from tkinter import *
import datetime
import sync3


#Paramêtres
sho=0 #affichage dtection
clean=1 #netoyage image

# Root directory of the project
ROOT_DIR = os.getcwd()

# Directory to save logs and trained model
MODEL_DIR = os.path.join(ROOT_DIR, "logs")

# Local path to trained weights file
COCO_MODEL_PATH = os.path.join(ROOT_DIR, "mask_rcnn_inclusion.h5")



config = inclusion.BalloonConfig()
class InferenceConfig(config.__class__):
    # Run detection on one image at a time
    GPU_COUNT = 1
    IMAGES_PER_GPU = 1
    DETECTION_MIN_CONFIDENCE = 0.9
    RPN_NMS_THRESHOLD = 0.7

config = InferenceConfig()
config.display()
# Create model object in inference mode.
model = modellib.MaskRCNN(mode="inference", model_dir=MODEL_DIR, config=config)

# Load weights trained on MS-COCO
model.load_weights(COCO_MODEL_PATH, by_name=True)

# COCO Class names
# Index of the class in the list is its ID. For example, to get ID of
# the teddy bear class, use: class_names.index('teddy bear')
class_names = ['BG', 'rayure', 'sal', 'a','c','d','ni']


#Definition des dossiers
dirName1 = r'Y:\brut'
dirName2 = r'Y:\clean'
dirName3=r'D:\IA'


#boucle infinie pour actualiser liste
while True:

    #comparaison des dossiers
    listOfFiles1 = sync3.getListOfFiles(dirName1,dirName1)
    listOfFiles2=sync3.getListOfFiles(dirName2,dirName2)
    #recherche des différences
    print('diff')
    file_diff = sorted(list(set(listOfFiles1) - set(listOfFiles2)))
    print(len(file_diff))
    #Creation de l'arboressance des dossiers
    sync3.createFolder(dirName1,dirName2)
    if sho==1:
        sync3.createFolder(dirName1,dirName3)




    
    if len(file_diff)>0:

        #recherche des fichiers images dans la listes
        noms= [nom for nom in file_diff if nom[-4:] == ".tif" or nom[-4:] == ".Tif" or nom[-4:] == ".bmp" or nom[-4:] == ".jpg"]
        nb_image=len(noms)




        #Lancement IA si liste non nul
        l=len(noms)
        if l>0:
            t0=time.time()
            i=0
            for nom in noms:
                i=i+1
                t=time.time()
                nfc = dirName1+ nom
                image=cv.imread(nfc)
                print(nom)
                
                if nom[-4:] == ".tif" or nom[-4:] == ".Tif":
                    #recuperation pâramêtre olympus
                    fd = open(nfc, 'rb')
                    d= fd.read()
                    xmp_start = re.search(b'analySIS',d)
                    xmp_end = re.search(b'Solutions',d)
                    xmp_str = d[:xmp_end.span()[0]+11]
                    xmp_str2 = d[xmp_start.span()[0]-16:]
                    fd.close()
                t1=time.time()
                # Run detection
                results = model.detect([image], verbose=0)
                # Save results
                r = results[0]
                t2=time.time()
                
                
                
                if sho+clean!=0:
                    #creation image de la détection
                    if sho==1:
                        
                        img=show.show(image,r['rois'],r['masks'], r['class_ids'],class_names,r['scores'],sho,clean)

                        nom_ia=nom[:-4]+".jpg"
                        path=dirName3+nom_ia
                        img.save(path)

                        del image
                        del img

                        image=cv.imread(nfc)

                        
                    #creation image nettoyer
                    if clean==1:

                        path2=dirName2+nom
                        img2=show2.show(image,r['rois'],r['masks'], r['class_ids'],class_names,r['scores'],sho,clean)

                        img2.save(path2)

                        #olympus
                        if nom[-4:] == ".tif" or nom[-4:] == ".Tif":
                            fd = open(path2, 'rb')
                            d= fd.read()
                            fd.close()
                            d=xmp_str+d[140:]+xmp_str2
                            fd = open(path2, 'w+b')
                            fd.write(d)
                            fd.close()

                        del image
                #affichage des informations
                t3=time.time()
                T1=t1-t
                T2=t2-t1
                T3=t3-t2
                T=t3-t
                print('Temps ouverture: %.2f s Temps IA %.2f s Temps ecriture %.2f s'%(T1,T2,T3))
                print('Temps total: %.2f s'%T)
                print('Temps estimé restant : %s Fichier : %s / %s'%(str(datetime.timedelta(seconds=round((t3-t0)/i*(l-i)))),str(i),str(l)))
    #attente de nouveauté
        else:
            print('Attend 1 min')
            time.sleep(60)
            
    else:
        print('Attend 1 min')
        time.sleep(60)
        
